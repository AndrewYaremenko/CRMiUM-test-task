let a = 36.57;
let b = 31.57;

console.log(((a - b) / a) * 100);